import React from 'react';
export function Image({ src, alt = '', className = '', style, ...props }) {
  return <img src={src} alt={alt} className={className} style={style} loading="eager" draggable="false" {...props} />;
}
