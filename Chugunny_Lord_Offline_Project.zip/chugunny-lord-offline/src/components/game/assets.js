export const PORTRAIT_URL = '/portrait.svg';
export const BUILDING_URL = '/building.svg';
export const MEME_URL = '/meme.svg';
export const SLEEP_URL = '/sleep.svg';
