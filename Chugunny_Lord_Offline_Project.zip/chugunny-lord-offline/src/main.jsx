import React from 'react';
import { createRoot } from 'react-dom/client';
import Game from './components/game/Game.jsx';
import './style.css';

createRoot(document.getElementById('root')).render(
  <React.StrictMode><Game /></React.StrictMode>
);
